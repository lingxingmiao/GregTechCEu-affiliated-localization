---
navigation:
  title: "电力高炉"
  icon: "modern_industrialization:electric_blast_furnace"
  position: 106
  parent: modern_industrialization:electric_age.md
item_ids:
  - modern_industrialization:electric_blast_furnace
  - modern_industrialization:cupronickel_coil
  - modern_industrialization:lv_energy_input_hatch
  - modern_industrialization:mv_energy_input_hatch
---

# 电力高炉

<GameScene zoom="2" interactive={true} fullWidth={true}>
    <MultiblockShape controller="electric_blast_furnace" />
</GameScene>

电力高炉是蒸汽高炉的电力版本。它解锁了新的配方，并且像其他多方块电力机器一样，其超频默认限制为128 EU/t。

<Recipe id="modern_industrialization:electric_age/machine/electric_blast_furnace_asbl" />

电高炉由一层耐热机械方块、两层空心白铜线圈和另一层耐热机械方块构成。控制器必须放置在底层，舱口放置在顶层或底层。

<Recipe id="modern_industrialization:materials/cupronickel/assembler/coil" />

别忘了添加能量输入舱口，否则电高炉将没有能量！LV能量输入舱口只能连接LV导线。

<Recipe id="modern_industrialization:hatches/basic/energy_input_hatch" />

MV能量输入舱口只能连接MV导线，如果你需要为电高炉提供大量能量，这会很有用！你现在还无法合成它们，但请记住它们的存在……

<Recipe id="modern_industrialization:hatches/advanced/energy_input_hatch" />

