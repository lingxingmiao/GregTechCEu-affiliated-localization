---
navigation:
  title: "高压！"
  icon: "modern_industrialization:pressurizer"
  position: 202
  parent: modern_industrialization:midgame.md
item_ids:
  - modern_industrialization:pressurizer
  - modern_industrialization:high_pressure_large_steam_boiler
  - modern_industrialization:high_pressure_advanced_large_steam_boiler
  - modern_industrialization:large_steam_turbine
  - modern_industrialization:heat_exchanger
  - modern_industrialization:hv_steam_turbine
---

# 高压！

## 加压器

<GameScene zoom="2" interactive={true} fullWidth={true}>
    <MultiblockShape controller="pressurizer" />
</GameScene>

增压器是一种由钛制成的新型多方块，可将水转化为高压（HP）水，将蒸汽转化为高压蒸汽，反之亦然。

<Recipe id="modern_industrialization:electric_age/machine/pressurizer_asbl" />

## 高压大型蒸汽锅炉

<GameScene zoom="2" interactive={true} fullWidth={true}>
    <MultiblockShape controller="high_pressure_large_steam_boiler" />
</GameScene>

一旦你获得了高压水的访问权限，就可以使用高压大型蒸汽锅炉来生产高压蒸汽。

1 mB 高压蒸汽相当于 8 mB 普通蒸汽，即 8 EU。

<Recipe id="modern_industrialization:electric_age/machine/high_pressure_large_steam_boiler_asbl" />

## 高压高级大型蒸汽锅炉

<GameScene zoom="2" interactive={true} fullWidth={true}>
    <MultiblockShape controller="high_pressure_advanced_large_steam_boiler" />
</GameScene>

稍后，你还将能够建造高压大型蒸汽锅炉的高级版本。

## 大型蒸汽涡轮机

<GameScene zoom="2" interactive={true} fullWidth={true}>
    <MultiblockShape controller="large_steam_turbine" />
</GameScene>

大型蒸汽涡轮机可将普通蒸汽（1 mB = 1 EU）和高压蒸汽（1 mB = 8 EU）转化为EU，最高产生16384 EU/t！**但它不会返还普通水或高压水。**

<Recipe id="statech:modern_industrialization/large_steam_turbine" />

## 热交换器

<GameScene zoom="2" interactive={true} fullWidth={true}>
    <MultiblockShape controller="heat_exchanger" />
</GameScene>

请记住，将水加压为高压水需要消耗大量能量，但涡轮机不会返还它！你可以使用热交换器回收高压水以进行下一轮循环。

<Recipe id="modern_industrialization:electric_age/machine/heat_exchanger_asbl" />

## HV蒸汽轮机

小型设置的另一个选择是使用HV蒸汽轮机。与其他HV发电机一样，它将产生512 EU/t。此设备仅接受常规蒸汽。

<Recipe id="modern_industrialization:electric_age/machine/hv_steam_turbine_asbl" />

