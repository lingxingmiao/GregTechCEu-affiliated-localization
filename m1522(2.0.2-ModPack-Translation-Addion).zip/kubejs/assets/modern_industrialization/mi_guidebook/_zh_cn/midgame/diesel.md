---
navigation:
  title: "更好的柴油"
  icon: "modern_industrialization:hv_diesel_generator"
  position: 204
  parent: modern_industrialization:midgame.md
item_ids:
  - modern_industrialization:hv_diesel_generator
  - modern_industrialization:large_diesel_generator
---

# 更好的柴油

## HV柴油发电机

请记住，你可以使用 HV 柴油发电机来实现紧凑的 HV 发电。不出所料，它最高能产生 1024 EU/t。记得使用 REI 查看每种燃料中存储的能量数量。

<Recipe id="modern_industrialization:electric_age/machine/hv_diesel_generator_asbl" />

## 大型柴油发电机

<GameScene zoom="2" interactive={true} fullWidth={true}>
    <MultiblockShape controller="large_diesel_generator" />
</GameScene>

一旦你能获取处理单元和高度先进的机器外壳，可以考虑制造几台大型柴油发电机。这些大家伙每台都能将燃料转化为 EU，最高可达 16384 EU/t！

<Recipe id="statech:modern_industrialization/large_diesel_generator" />

