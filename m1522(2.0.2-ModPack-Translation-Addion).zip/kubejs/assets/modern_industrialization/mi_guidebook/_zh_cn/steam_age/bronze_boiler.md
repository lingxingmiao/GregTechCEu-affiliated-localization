---
navigation:
  title: "烧开水"
  icon: "modern_industrialization:bronze_boiler"
  position: 2
  parent: modern_industrialization:steam_age.md
item_ids:
  - modern_industrialization:steam_bucket
  - modern_industrialization:bronze_boiler
  - modern_industrialization:fire_clay_dust
---

# 烧开水

蒸汽机器需要蒸汽才能运行，而这正是锅炉所提供的。

它会缓慢消耗燃料进行升温。当温度足够高时，它将开始产生蒸汽。

它现在看起来可能很贵，但别忘了你可以用锻锤将矿石三倍化。而且，一旦你有了前两台机器，成本就会降低一半以上！

<Recipe id="modern_industrialization:steam_age/bronze/boiler_asbl" />

要制作耐火砖，你需要烧炼耐火粘土粉，而要合成这些材料，你需要砖粉。要制作一些，请将砖块放入锻锤中。该过程的效率可以在蒸汽机器中提高，或者使用锤子。

<Recipe id="modern_industrialization:materials/fire_clay_dust" />

