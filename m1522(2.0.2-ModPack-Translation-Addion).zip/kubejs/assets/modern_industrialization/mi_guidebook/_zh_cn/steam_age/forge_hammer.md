---
navigation:
  title: "入门指南"
  icon: "modern_industrialization:forge_hammer"
  parent: modern_industrialization:steam_age.md
item_ids:
  - modern_industrialization:iron_hammer
  - modern_industrialization:forge_hammer
  - modern_industrialization:steam_mining_drill
---

# 入门指南

在制作青铜之前，我们需要创建一个锻锤。它用于基础加工步骤。

你可以将铁、铜和锡矿石放入锻锤中，每块矿石可获得 2 个原生矿石。使用锤子可以提高这一比率。每个原生矿石都可以熔炼成锭。

锻造锤提高了锻炉锤的比率，并解锁了更多配方，但会消耗一些耐久度。

<Recipe id="statech:modern_industrialization/iron_hammer" />

现在，你可能需要考虑制作蒸汽采矿钻头，以便直接获取矿石，而无需使用带有精准采集附魔的镐。

<Recipe id="modern_industrialization:forge_hammer" />

蒸汽采矿钻头一次可以挖掘3×3的方块，非常适合你早期的采矿需求！它还具有精准采集功能，与锻炉锤配合得很好。

<Recipe id="modern_industrialization:tools/steam_mining_drill" />

蒸汽采矿钻头需要水和固体燃料（例如煤炭）。

右键点击水源以注水，并确保通过右键点击物品栏中的燃料物品，始终在钻头中放置一些燃料。当你采矿时，燃料会被缓慢消耗。

