---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 接口
  icon: interface
  position: 210
categories:
- devices
item_ids:
- ae2:interface
- ae2:cable_interface
---

# 接口

<Row gap="20">
<BlockImage id="interface" scale="8" />
<GameScene zoom="8" background="transparent">
  <ImportStructure src="../assets/blocks/cable_interface.snbt" />
</GameScene>
</Row>

接口就像一个小型箱子和流体储罐，会根据你在其槽位中设置的库存进行填充和清空。它会在一个游戏刻内尝试完成这一过程，因此每游戏刻最多可从 [网络存储](../ae2-mechanics/import-export-storage.md)
填充自身或向
清空最多9组物品，如果你有快速物品管道，这是一种快速的导入或导出方式。

另一个实用的特性是，虽然大多数流体储罐只能存储 1 种流体，但接口最多可以存储 9 种流体，以及物品。
它们本质上只是带有一些额外功能的箱子/多流体储罐，你可以通过保持
它们与任何网络断开连接来阻止这些额外功能。
因此，在需要存储少量多种不同物品的特殊情况下，它们非常实用。

## 接口内部工作原理

如前所述，接口本质上是一个带有超级杜佩尔功能的箱子/储罐 <ItemLink id="import_bus" />ses and
<ItemLink id="export_bus" />ses attached, with a bunch of <ItemLink id="level_emitter" />秒。

<GameScene zoom="3" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_internals.snbt" />

  <BoxAnnotation color="#dddddd" min="1.3 0.3 1.3" max="9.7 1 1.7">
        A bunch of level emitters to control the requested stocking quantity
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/level_emitter.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 4 1.3" max="9.7 4.7 1.7">
        A bunch of level emitters to control the requested stocking quantity
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/level_emitter.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 1.3 1.3" max="9.7 2 1.7">
        一组超级无敌的导入总线，每游戏刻可传输1组物品
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/import_bus.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1.3 3 1.3" max="9.7 3.7 1.7">
        一组超级无敌的导出总线，每游戏刻可传输1组物品
        <GameScene zoom="4" background="transparent">
        <ImportStructure src="../assets/blocks/export_bus.snbt" />
        </GameScene>
  </BoxAnnotation>

  <BoxAnnotation color="#dddddd" min="1 2 1" max="10 3 2">
        9个独立的内部槽位
  </BoxAnnotation>

  <IsometricCamera yaw="195" pitch="15" />
</GameScene>

## 特殊交互

接口与其他AE2 [设备](../ae2-mechanics/devices.md):

A <ItemLink id="storage_bus" /> 在未配置的接口上会显示完整的 [网络存储](../ae2-mechanics/import-export-storage.md)
将其网络的物品传输至存储总线的网络，仿佛接口的网络是一个放置了存储总线的大型箱子。
在接口的过滤槽中设置物品以进行存储会禁用此功能。

<GameScene zoom="6" interactive={true}>
  <ImportStructure src="../assets/assemblies/interface_storage.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

样板供应器与接口之间存在特殊的交互机制 [子网](../ae2-mechanics/subnetworks.md): 如果接口未配置
供应器将完全跳过接口，直接推送到该子网的 [存储](../ae2-mechanics/import-export-storage.md),
跳过接口且不向其填充配方批次，更重要的是，在存储有空间之前不插入下一批次。

<GameScene zoom="6" background="transparent">
<ImportStructure src="../assets/assemblies/provider_interface_storage.snbt" />

<BoxAnnotation color="#dddddd" min="2.7 0 1" max="3 1 2">
        接口（必须为平面，而非完整方块）
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="1 0 0" max="1.3 1 4">
        存储总线
  </BoxAnnotation>

<BoxAnnotation color="#dddddd" min="0 0 0" max="1 1 4">
        需要向其提供样板的目标（多台机器，或同一台机器的多个面）
  </BoxAnnotation>

<IsometricCamera yaw="185" pitch="30" />
</GameScene>

## 变体

接口有2种不同的变体：normal和flat/[子部件](../ae2-mechanics/cable-subparts.md)。这会影响其物品栏可以从哪些特定侧面访问
以及它们是否提供网络连接。

*   普通接口允许物品从所有侧面推入、拉出和访问其物品栏，并且像大多数AE2机器一样，充当
    像一根为所有侧面提供网络连接的线缆。

*   平坦接口是 [电缆子部件](../ae2-mechanics/cable-subparts.md)，因此可以在同一根线缆上放置多个，从而实现紧凑布局。
    它们允许物品从正面推入、拉出和访问其物品栏，但正面不提供网络连接。

接口可以在合成网格中在普通和扁平之间切换。

## 设置

接口中的上方槽位决定了接口内部设定的存储内容。当有物品被放入
其中或从JEI/REI拖拽时，会出现一个扳手，让你设置数量。

使用流体容器（如桶或流体储罐）右键点击，可将该流体设置为过滤器，而非桶或储罐物品本身。

当你将插槽设置为补货模式时，它也会阻止外部机器向该插槽插入其他物品。

## 升级

接口支持以下 [升级](upgrade_cards.md):

*   <ItemLink id="fuzzy_card" /> 使总线能够按耐久度等级和/或忽略物品NBT进行筛选
*   <ItemLink id="crafting_card" /> 让接口向你的 [自动合成](../ae2-mechanics/autocrafting.md)
    系统获取其所需的物品。如果可能，它会先从存储中拉取物品，然后再发出请求
    用于制作新物品。

## 优先级

可以通过点击GUI右上角的扳手来设置优先级。优先级较高的接口会先获取其物品
优先级较低的接口则在其之后获取，

## 配方

<Recipe id="statech:ae2/interface" />

<RecipeFor id="cable_interface" />
