---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 处理器
  icon: logic_processor
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:logic_processor
- ae2:calculation_processor
- ae2:engineering_processor
- ae2:printed_silicon
- ae2:printed_logic_processor
- ae2:printed_calculation_processor
- ae2:printed_engineering_processor
- ae2:silicon
---

# 处理器

<Row>
  <ItemImage id="logic_processor" scale="4" />

  <ItemImage id="calculation_processor" scale="4" />

  <ItemImage id="engineering_processor" scale="4" />
</Row>

处理器是AE2中的主要原料之一 [设备](../ae2-mechanics/devices.md) 和机器。它们也是你最先
大型自动化挑战。处理器有三种类型，使用金制作， <ItemLink id="certus_quartz_crystal" />,
以及钻石。它们使用 [压印器](presses.md) 在装配器中，通过多步骤
流程（通常通过一系列打包机、装配器和过滤管道实现）。

## 生产步骤

<Column gap="5">
  1.  收集/制作所需材料：硅、熔融红石、金， <ItemLink id="certus_quartz_crystal" />钻石。

  <br />

  2.  将前置电路板组件在打包机中压制

  <br />

  3.  最后，在装配器中使用熔融红石将它们组装

</Column>
