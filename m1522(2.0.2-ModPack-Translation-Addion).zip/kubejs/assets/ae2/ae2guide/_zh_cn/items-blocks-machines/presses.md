---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 压印器
  icon: silicon_press
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:silicon_press
- ae2:logic_processor_press
- ae2:calculation_processor_press
- ae2:engineering_processor_press
- ae2:name_press
---

# 压印器

打包机中使用5种不同的压机。

<Row>
  <ItemImage id="silicon_press" scale="4" />

  <ItemImage id="logic_processor_press" scale="4" />

  <ItemImage id="calculation_processor_press" scale="4" />

  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

<ItemImage id="name_press" scale="4" />

## 处理器压印器

硅、逻辑、计算和工程压印器用于生产 [处理器](processors.md).
这4种压印器通过破坏一个 <ItemLink id="mysterious_cube" /> 在 [陨石](../ae2-mechanics/meteorites.md).
它们也可以在打包机中复制。

## 名称压印模板

名称压印模板可在压印器中用于为物品命名，类似于铁砧。

要合成，请右键点击 <ItemLink id="certus_quartz_cutting_knife" /> 或 <ItemLink id="nether_quartz_cutting_knife" />
并放入一块金属锭，然后你必须输入你想要的名称
想要刻写到镶板上，然后直接取出完成的镶板。你可以在压印器中一次使用一个或两个镶板，
如果你使用两个镶板，它将结合两个名称进行打印，顺序为顶部槽位，然后是底部槽位。
