---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 存储元件
  icon: item_storage_cell_1k
  position: 410
categories:
- tools
item_ids:
- ae2:item_cell_housing
- ae2:fluid_cell_housing
- ae2:cell_component_1k
- ae2:cell_component_4k
- ae2:cell_component_16k
- ae2:cell_component_64k
- ae2:cell_component_256k
- ae2:item_storage_cell_1k
- ae2:item_storage_cell_4k
- ae2:item_storage_cell_16k
- ae2:item_storage_cell_64k
- ae2:item_storage_cell_256k
- ae2:fluid_storage_cell_1k
- ae2:fluid_storage_cell_4k
- ae2:fluid_storage_cell_16k
- ae2:fluid_storage_cell_64k
- ae2:fluid_storage_cell_256k
---

# 存储元件

<Column>
  <Row>
    <ItemImage id="item_storage_cell_1k" scale="4" />

    <ItemImage id="item_storage_cell_4k" scale="4" />

    <ItemImage id="item_storage_cell_16k" scale="4" />

    <ItemImage id="item_storage_cell_64k" scale="4" />

    <ItemImage id="item_storage_cell_256k" scale="4" />
  </Row>

  <Row>
    <ItemImage id="fluid_storage_cell_1k" scale="4" />

    <ItemImage id="fluid_storage_cell_4k" scale="4" />

    <ItemImage id="fluid_storage_cell_16k" scale="4" />

    <ItemImage id="fluid_storage_cell_64k" scale="4" />

    <ItemImage id="fluid_storage_cell_256k" scale="4" />
  </Row>
</Column>

存储元件是应用能源中的主要存储方式之一。它们放入 <ItemLink id="drive" />秒
或 <ItemLink id="chest" />秒。

查看 [字节与类型](../ae2-mechanics/bytes-and-types.md) 以了解其字节容量和类型。

如果元件为空，手持元件并按住Shift右键点击，即可从外壳中取出存储组件。

<Row>
    <Recipe id="upgrade/item_storage_cell_1k_to_4k" />

    你可以在合成网格中，将存储元件与更高等级的存储元件组合，从而将存储元件升级至更高等级。其内容将被保留，且较低等级的元件会被返还。
</Row>

## 不同类型数量下的存储容量

需要 [类型的预先成本](../ae2-mechanics/bytes-and-types.md) 使得一个仅存储1种物品的元件，其容量是存储全部63种物品元件的2倍。

| 元件                                     | 使用 1 种类型的单元总容量 | 使用 63 种类型的单元总容量 |
| ---------------------------------------- | ----------------------------------------: | ------------------------------------------: |
| <ItemLink id="item_storage_cell_1k" />   |                                     8,128 |                                       4,160 |
| <ItemLink id="item_storage_cell_4k" />   |                                    32,512 |                                      16,640 |
| <ItemLink id="item_storage_cell_16k" />  |                                   130,048 |                                      66,560 |
| <ItemLink id="item_storage_cell_64k" />  |                                   520,192 |                                     266,240 |
| <ItemLink id="item_storage_cell_256k" /> |                                 2,080,768 |                                   1,064,960 |


## 分区

元件可以设置过滤，仅接受特定物品，类似于 <ItemLink id="storage_bus" />的过滤方式。这是
在...内完成 <ItemLink id="cell_workbench" />.

即使你实际上没有该物品，也可以将物品从 JEI/REI 拖入槽位。

## 升级

存储元件支持以下 [升级](upgrade_cards.md), 通过 <ItemLink id="cell_workbench" />:

*   <ItemLink id="fuzzy_card" /> （流体元件不支持此功能）允许按耐久度等级和/或忽略物品 NBT 标签对元件进行分区
*   <ItemLink id="inverter_card" /> 将过滤器从白名单切换为黑名单
*   <ItemLink id="equal_distribution_card" /> 插入时，会为每种类型分配相同的单元字节空间，因此一种类型无法填满整个单元
*   <ItemLink id="void_card" /> 如果单元已满（或该特定类型在单元中分配的空间已满），则清空插入的物品
    （例如均分磁卡的情况），有助于防止农场堵塞。请注意对此进行分区！
*   便携元件可以接受 <ItemLink id="energy_card" /> 以增加其电池容量

## 上色

便携式物品和流体元件可以像皮革盔甲一样，通过与染料合成来进行上色。

# 外壳

元件可以通过存储元件和外壳制作，或者使用围绕存储元件的外壳配方制作：

<Row>
  <Recipe id="statech:ae2/item_storage_cell_1k" />

  <Recipe id="network/cells/item_storage_cell_1k_storage" />
</Row>

外壳本身的合成方式如下：

<Row>
  <RecipeFor id="item_cell_housing" />

  <RecipeFor id="fluid_cell_housing" />
</Row>

# 存储元件

存储元件是所有AE2元件的核心，决定元件的容量。每个层级使容量
增加4倍，并消耗上一级元件的3倍

<Column>
  <Row>
    <RecipeFor id="cell_component_1k" />

    <RecipeFor id="cell_component_4k" />

    <RecipeFor id="cell_component_16k" />
  </Row>

  <Row>
    <RecipeFor id="cell_component_64k" />

    <RecipeFor id="cell_component_256k" />
  </Row>
</Column>

# 物品存储元件

物品存储元件最多可容纳63种不同的物品，并提供所有标准容量。

<Column>
  <Row>
    <Recipe id="network/cells/item_storage_cell_1k_storage" />

    <Recipe id="network/cells/item_storage_cell_4k_storage" />

    <Recipe id="network/cells/item_storage_cell_16k_storage" />
  </Row>

  <Row>
    <Recipe id="network/cells/item_storage_cell_64k_storage" />

    <Recipe id="network/cells/item_storage_cell_256k_storage" />
  </Row>
</Column>

## 便携式物品存储

这些就像你口袋里的一个微型 <ItemLink id="chest" /> ，或者像一种背包。它们可以在 <ItemLink id="charger" />

中充电。与标准存储元件不同，这些元件实际上会随着字节容量的增加而*减少*类型容量，并且只有标准容量的一半
总字节容量。

除了所有元件都能接收的升级卡外，这些元件还能接收 <ItemLink id="energy_card" />s 以升级其内部电池。

<Column>
  <Row>
    <RecipeFor id="portable_item_cell_1k" />

    <RecipeFor id="portable_item_cell_4k" />

    <RecipeFor id="portable_item_cell_16k" />
  </Row>

  <Row>
    <RecipeFor id="portable_item_cell_64k" />

    <RecipeFor id="portable_item_cell_256k" />
  </Row>
</Column>

# 流体存储元件

流体存储元件最多可容纳5种不同的流体，并提供所有标准容量。

<Column>
  <Row>
    <Recipe id="network/cells/fluid_storage_cell_1k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_4k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_16k_storage" />
  </Row>

  <Row>
    <Recipe id="network/cells/fluid_storage_cell_64k_storage" />

    <Recipe id="network/cells/fluid_storage_cell_256k_storage" />
  </Row>
</Column>

## 便携式流体存储元件

这些就像你口袋里的一个微型 <ItemLink id="chest" /> ，或者像一种背包。它们可以在 <ItemLink id="charger" />

中充电。与标准存储元件不同，这些元件实际上会随着字节容量的增加而*减少*类型容量，并且只有标准容量的一半
总字节容量。

除了所有元件都能接收的升级卡外，这些元件还能接收 <ItemLink id="energy_card" />s 以升级其内部电池。

<Column>
  <Row>
    <RecipeFor id="portable_fluid_cell_1k" />

    <RecipeFor id="portable_fluid_cell_4k" />

    <RecipeFor id="portable_fluid_cell_16k" />
  </Row>

  <Row>
    <RecipeFor id="portable_fluid_cell_64k" />

    <RecipeFor id="portable_fluid_cell_256k" />
  </Row>
</Column>

# 创造存储元件

<Row>
  <ItemImage id="creative_storage_cell" scale="2" />
</Row>

创造元件**不提供无限存储**。相反，它们充当你所选择的任何
物品或流体的无限来源和汇点 [分区](cell_workbench.md) 他们。
