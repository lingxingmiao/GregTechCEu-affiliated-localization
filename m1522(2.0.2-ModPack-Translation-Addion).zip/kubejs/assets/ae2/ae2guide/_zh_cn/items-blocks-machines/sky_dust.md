---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 天空石粉
  icon: sky_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:sky_dust
---

# 天空石粉

<ItemImage id="sky_dust" scale="4" />

A <ItemLink id="sky_stone_block" /> 被压碎的方块 <ItemLink id="inscriber" />. 用于生产
<ItemLink id="cell_component_256k" /> 和 <ItemLink id="sky_stone_block" />.

也可以通过将 <ItemLink id="annihilation_plane" /> 向上指向世界高度限制来获取。

## 合成

你可以在研磨机中制作天石粉尘
