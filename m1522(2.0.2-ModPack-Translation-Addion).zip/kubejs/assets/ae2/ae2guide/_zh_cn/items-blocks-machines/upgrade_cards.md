---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 升级卡
  icon: speed_card
  position: 410
categories:
- tools
item_ids:
- ae2:basic_card
- ae2:advanced_card
- ae2:redstone_card
- ae2:capacity_card
- ae2:void_card
- ae2:fuzzy_card
- ae2:speed_card
- ae2:inverter_card
- ae2:crafting_card
- ae2:equal_distribution_card
- ae2:energy_card
---

# 升级卡

<Row>
  <ItemImage id="redstone_card" scale="2" />

  <ItemImage id="capacity_card" scale="2" />

  <ItemImage id="void_card" scale="2" />

  <ItemImage id="fuzzy_card" scale="2" />

  <ItemImage id="speed_card" scale="2" />

  <ItemImage id="inverter_card" scale="2" />

  <ItemImage id="crafting_card" scale="2" />

  <ItemImage id="equal_distribution_card" scale="2" />

  <ItemImage id="energy_card" scale="2" />
</Row>

升级卡会改变 AE2 的 [设备](../ae2-mechanics/devices.md) 和机器，提升其速度，增强其
过滤器容量，启用红石控制，等等。

## 卡牌组件

<Row>
  <ItemImage id="basic_card" scale="2" />

  <ItemImage id="advanced_card" scale="2" />
</Row>

卡牌使用基础或高级卡牌底座合成

<Row>
  <RecipeFor id="basic_card" />

  <RecipeFor id="advanced_card" />
</Row>

## 红石卡

<ItemImage id="redstone_card" scale="2" />

红石卡添加红石控制，在设备的界面内添加一个切换按钮，以在各种红石条件之间切换。

<RecipeFor id="redstone_card" />

## 容量卡

<ItemImage id="capacity_card" scale="2" />

容量卡可增加导入总线、导出总线、存储总线及形成平面中的过滤槽位数量。

<RecipeFor id="capacity_card" />

## 溢出销毁卡

<ItemImage id="void_card" scale="2" />

溢出销毁卡可以应用于 [存储元件](storage_cells.md) 在 <ItemLink id="cell_workbench" />
，并且当元件已满时，将删除传入的物品。（请务必 [分区](cell_workbench.md) 你的元件！）结合均衡分配卡，
如果元件中特定物品的栏位已满，即使其他物品的栏位为空，这些物品也会被销毁。

<RecipeFor id="void_card" />

## 模糊卡

<ItemImage id="fuzzy_card" scale="2" />

模糊卡允许带有过滤器的设备和工具按耐久等级过滤和/或忽略物品NBT，从而允许你导出
无论伤害等级和附魔如何，所有铁制斧头，或者仅导出受损的钻石剑，而非完全修复的。

以下是模糊伤害比较模组工作原理的示例，左侧是
总线配置，顶部是被比较的物品。

| 25%                    | 10% 损坏的镐 | 30% 损坏的镐 | 80% 损坏的镐 | 满耐久修复镐 |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| 几乎损坏的镐  | ✅                   | \*\*\*\*            | \*\*\*\*            | \*\*\*\*            |
| 完全修复的镐 | \*\*\*\*            | ✅                   | ✅                   | ✅                   |

| 50%                    | 10% 损坏的镐 | 30% 损坏的镐 | 80% 损坏的镐 | 满耐久修复镐 |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| 几乎损坏的镐  | ✅                   | ✅                   | \*\*\*\*            | \*\*\*\*            |
| 完全修复的镐 | \*\*\*\*            | \*\*\*\*            | ✅                   | ✅                   |

| 75%                    | 10% 损坏的镐 | 30% 损坏的镐 | 80% 损坏的镐 | 满耐久修复镐 |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| 几乎损坏的镐  | ✅                   | ✅                   | \*\*\*\*            | \*\*\*\*            |
| 完全修复的镐 | \*\*\*\*            |                     | ✅                   | ✅                   |

| 99%                    | 10% 损坏的镐 | 30% 损坏的镐 | 80% 损坏的镐 | 满耐久修复镐 |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| 几乎损坏的镐  | ✅                   | ✅                   | ✅                   | \*\*\*\*            |
| 完全修复的镐 | \*\*\*\*            | \*\*\*\*            | \*\*\*\*            | ✅                   |

| 忽略                 | 10% 损坏的镐 | 30% 损坏的镐 | 80% 损坏的镐 | 满耐久修复镐 |
| ---------------------- | ------------------- | ------------------- | ------------------- | ------------------- |
| 几乎损坏的镐  | ✅                   | ✅                   | ✅                   | **✅**               |
| 完全修复的镐 | **✅**               | **✅**               | **✅**               | ✅                   |

<RecipeFor id="fuzzy_card" />

## 加速卡

<ItemImage id="speed_card" scale="2" />

加速卡使事物运行得更快，使导入和导出总线每次操作移动更多物品，并使压印器
并且装配器的工作速度更快。

<RecipeFor id="speed_card" />

## 反相卡

<ItemImage id="inverter_card" scale="2" />

反相卡可将设备和工具中的过滤器从白名单切换为黑名单。

<RecipeFor id="inverter_card" />

## 合成卡

<ItemImage id="crafting_card" scale="2" />

合成卡允许设备向您的 [自动合成](../ae2-mechanics/autocrafting.md)
系统以获取其所需的物品。

<RecipeFor id="crafting_card" />

## 均分卡

<ItemImage id="equal_distribution_card" scale="2" />

均分卡可以应用于 [存储元件](storage_cells.md) 在 <ItemLink id="cell_workbench" /> 的力量
根据卡片内容将单元分割为等大的部分 [被分区](cell_workbench.md) to. 这可以防止一种物品类型完全
填满元件。

<RecipeFor id="equal_distribution_card" />

## 能量卡

<ItemImage id="energy_card" scale="2" />

能量卡为便携式终端等特定工具增加更多能量存储，并使其 <ItemLink id="vibration_chamber" />秒
更高效。

<RecipeFor id="energy_card" />
