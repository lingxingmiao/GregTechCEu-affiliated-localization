---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 空间单元
  icon: spatial_storage_cell_128
  position: 410
categories:
- tools
item_ids:
- ae2:spatial_storage_cell_2
- ae2:spatial_storage_cell_16
- ae2:spatial_storage_cell_128
- ae2:spatial_cell_component_2
- ae2:spatial_cell_component_16
- ae2:spatial_cell_component_128
---

# 空间存储元件

  <Row>
    <ItemImage id="spatial_storage_cell_2" scale="4" />

    <ItemImage id="spatial_storage_cell_16" scale="4" />

    <ItemImage id="spatial_storage_cell_128" scale="4" />
  </Row>

空间存储元件用于 [存储物理空间体积](../ae2-mechanics/spatial-io.md).
它们用于 <ItemLink id="spatial_io_port" />.

与 [存储元件](../items-blocks-machines/storage_cells.md)不同，空间单元无法重新格式化。

再次，**空间单元使用后无法重置、重新格式化或调整尺寸。** 如需使用不同尺寸，请制作新的单元。


## 配方

  <Row>
    <Recipe id="network/cells/spatial_storage_cell_2_cubed_storage" />

    <Recipe id="network/cells/spatial_storage_cell_16_cubed_storage" />

    <Recipe id="network/cells/spatial_storage_cell_128_cubed_storage" />
  </Row>

# 外壳

空间单元可通过空间元件与外壳制作，或在空间元件周围使用外壳配方制作：

<Row>
  <Recipe id="statech:ae2/spatial_storage_cell_2" />

  <Recipe id="network/cells/spatial_storage_cell_2_cubed_storage" />
</Row>

外壳本身的合成方式如下：

  <RecipeFor id="item_cell_housing" />

# 空间元件

空间元件是空间存储元件的核心。每个层级都会增加可存储的体积维度
存储倍数为8。

  <Row>
    <RecipeFor id="spatial_cell_component_2" />

    <RecipeFor id="spatial_cell_component_16" />

    <RecipeFor id="spatial_cell_component_128" />
  </Row>
