---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 福鲁伊克斯水晶
  icon: fluix_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:fluix_crystal
---

# 该福鲁伊克斯水晶

<ItemImage id="fluix_crystal" scale="4" />

*"福鲁伊克斯水晶拥有将能量从一种形态吸收并转换为另一种形态的独特能力，并且是
所有『物质』能量科技"*

AE2方块的主要原料之一， [设备](../ae2-mechanics/devices.md), 以及物品。通过将下界石英、红石和
<ItemLink id="charged_certus_quartz_crystal" /> 投入水中制成。

可 [自动化](../example-setups/throw-in-water-automation.md) ，使用 <ItemLink id="formation_plane" /> 和 <ItemLink id="annihilation_plane" />.

## 配方

福鲁伊克斯水晶可以在混合器中使用石英、红石粉尘和充能赛特斯石英水晶制作。

<Row>
  <Recipe id="misc/deconstruction_fluix_block" />
</Row>
