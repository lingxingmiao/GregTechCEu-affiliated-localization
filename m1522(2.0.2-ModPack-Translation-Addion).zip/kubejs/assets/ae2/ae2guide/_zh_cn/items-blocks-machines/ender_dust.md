---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 末影粉
  icon: ender_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:ender_dust
---

# 末影粉

<ItemImage id="ender_dust" scale="4" />

一颗被压碎的 <ItemLink id="inscriber" />。用于生产 <ItemLink id="wireless_booster" />秒
和 <ItemLink id="quantum_entangled_singularity" /> 对。

## 合成

末影粉尘可在研磨机中制作。
