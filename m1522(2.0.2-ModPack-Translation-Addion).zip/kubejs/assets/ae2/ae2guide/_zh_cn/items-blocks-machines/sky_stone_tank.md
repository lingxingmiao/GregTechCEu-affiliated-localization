---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 天空石储罐
  icon: sky_stone_tank
  position: 310
categories:
- machines
item_ids:
- ae2:sky_stone_tank
---

# 天空石储罐

<BlockImage id="sky_stone_tank" scale="8" />

这是一个可存储16桶流体的流体储罐。被采集时不会保留其内容物。没什么好说的了。

## 合成

天石储罐在StaTech Industry中已禁用。
