---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 压印器
  icon: inscriber
  position: 310
categories:
- machines
item_ids:
- ae2:inscriber
---

# 压印器

<BlockImage id="inscriber" scale="8" />

压印器用于刻印电路和 [处理器](processors.md) 使用 [压印器](presses.md)，以及将各种物品粉碎成粉尘。
它可以接受AE2的能量（AE）或Fabric/Forge能量（E/FE）。它可以设置方向，使得从不同侧面插入物品
将其插入物品栏中的不同槽位。为了方便操作，可以使用 <ItemLink id="certus_quartz_wrench" />.
它还可以设置为将合成结果推送到相邻的库存。

输入缓存的大小可以调整。例如，如果你想从一个库存向大型压印器阵列供料，
你想要一个小型缓存器，以便材料在压印器之间更优化地分配（而不是第一个
压印器填满到64，其余的为空）。

这4个电路压印器用于合成 [处理器](processors.md)

<Row>
  <ItemImage id="silicon_press" scale="4" />

  <ItemImage id="logic_processor_press" scale="4" />

  <ItemImage id="calculation_processor_press" scale="4" />

  <ItemImage id="engineering_processor_press" scale="4" />
</Row>

虽然名称冲压器可用于为方块命名，类似于铁砧，便于为物品添加标签， <ItemLink id="pattern_access_terminal" />.

<ItemImage id="name_press" scale="4" />

## 设置

* 压印器可设置为定向模式（如下文所述），或允许从任意侧面将输入放入任意槽位，由内部过滤器决定
    物品去向。在非定向模式下，无法从顶部和底部槽位提取物品。
* 压印器可设置为将物品推入相邻的库存。
* 输入缓存区的大小可以调整，大型选项适用于手动饲育的独立压印器，而
小型选项则使大规模并行设置更具可行性。

## 界面与方向性

在方向模式下，压印器会根据你插入或提取物品的侧面来筛选物品的去向。

![压印器界面](../assets/diagrams/inscriber_gui.png) ![压印器侧面](../assets/diagrams/inscriber_sides.png)

A. **顶部输入** 通过压印器的顶面访问（物品可以推入和拉出此槽位）

B. **中心输入** 通过压印器的左、右、前和后侧面插入（物品只能推入此槽位，不能拉出）

C. **底部输入**：通过压印器的底面访问（物品可以推入或从此槽位拉出）

D. **输出**：通过压印器的左、右、前和后侧面拉出（物品只能从此槽位拉出，不能推入）

## 简易自动化

例如，侧面定向和可旋转性意味着你可以像这样半自动化压印器：

<GameScene zoom="4" background="transparent">
  <ImportStructure src="../assets/assemblies/inscriber_hopper_automation.snbt" />
  <IsometricCamera yaw="195" pitch="30" />
</GameScene>

或者在侧面定向模式下，直接通过管道将物品送入和送出压印器。

## 升级

压印器支持以下 [升级](upgrade_cards.md):

*   <ItemLink id="speed_card" />

## 合成

在StaTech Industry中，刻印器已被禁用。刻印配方改为在打包机中进行。
