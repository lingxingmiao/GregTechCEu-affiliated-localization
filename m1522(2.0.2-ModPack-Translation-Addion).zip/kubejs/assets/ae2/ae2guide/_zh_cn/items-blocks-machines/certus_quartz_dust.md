---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 赛特斯石英粉
  icon: certus_quartz_dust
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_dust
---

# 赛特斯石英粉

<ItemImage id="certus_quartz_dust" scale="4" />

A <ItemLink id="certus_quartz_crystal" /> 已被压碎的 <ItemLink id="inscriber" />. 用于生产
多种AE2材料与组件。

## 合成

赛特斯石英粉尘可在研磨机中制作。
