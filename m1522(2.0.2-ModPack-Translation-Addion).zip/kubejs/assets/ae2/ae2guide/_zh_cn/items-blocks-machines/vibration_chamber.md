---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 振动腔
  icon: vibration_chamber
  position: 110
categories:
- network infrastructure
item_ids:
- ae2:vibration_chamber
---

# 振动室

<BlockImage id="vibration_chamber" p:active="true" scale="8" />

虽然为网络提供的主要预期方法是 [能量](../ae2-mechanics/energy.md) 一个
<ItemLink id="energy_acceptor" />, 振动室可直接产生少量至中量的AE。

默认情况下（无 [升级](upgrade_cards.md) 且默认配置）它产生40 AE/t。

当网络的 [能量](../ae2-mechanics/energy.md) 存储已满时，振动室会降低输出以节省
燃料，但无法完全关闭。

## 设置

*   振动室提供访问全局设置的权限，以查看AE或E/FE中的能量。

## 升级

振动室支持以下内容 [升级](upgrade_cards.md):

*   <ItemLink id="energy_card" /> 将振动室的效率提高+50%，最大可达+150%，即基础效率的250%。
*   <ItemLink id="speed_card" /> 将振动室的燃烧速率提高+50%，最大可达+150%，即基础功率输出的250%。

## 配置

振动室的属性可在 .minecraft\config\ae2 文件夹下的 common.json 中编辑。
目录。

*   baseEnergyPerFuelTick 设置振动室的基础、未升级效率。
*   minEnergyPerGameTick 设置最低可能的能量生成量（即使网络
    不需要能量）。
*   maxEnergyPerGameTick 设置未升级的振动室的最高输出（和速度）。

## 合成

振动室在StaTech Industry中已禁用。
