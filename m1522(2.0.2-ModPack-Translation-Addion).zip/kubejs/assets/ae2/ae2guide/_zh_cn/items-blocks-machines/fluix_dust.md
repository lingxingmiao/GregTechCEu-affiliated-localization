---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 福鲁伊克斯粉
  icon: fluix_dust
  position: 010
categories:
- misc ingredients blocks
- network infrastructure
item_ids:
- ae2:fluix_dust
---

# 福鲁伊克斯粉

<ItemImage id="fluix_dust" scale="4" />

A <ItemLink id="fluix_crystal" /> 已被压碎的 <ItemLink id="inscriber" />. 用于生产
AE2的多种机器和组件。

## 合成

福鲁伊克斯粉尘可以在研磨机中制作。
