---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: 赛特斯石英晶体
  icon: certus_quartz_crystal
  position: 010
categories:
- misc ingredients blocks
item_ids:
- ae2:certus_quartz_crystal
---

# 赛特斯石英晶体

<ItemImage id="certus_quartz_crystal" scale="4" />

*“赛特斯石英晶体具有接受大量能量进入其晶体基质的独特属性”*

AE2方块的主要原料之一， [设备](../ae2-mechanics/devices.md)，以及物品。通过从 [萌芽赛特斯石英中培育而成](../ae2-mechanics/certus-growth.md).

## 部分替代配方

<Recipe id="misc/deconstruction_certus_quartz_block" />

赛特斯石英晶体也可以在混合器中制作，原料为赛特斯粉尘和充能赛特斯石英。
