---
navigation:
    title: '木质温室'
    icon: 'yet_another_industrialization:arboreous_greenhouse'
    position: 0
    parent: yet_another_industrialization:machines.md
item_ids:
    - yet_another_industrialization:arboreous_greenhouse
    - yet_another_industrialization:nutrient_rich_water_bucket
    - yet_another_industrialization:nutrient_rich_lava_bucket
    - yet_another_industrialization:dragon_breath_bucket
    - yet_another_industrialization:nutrient_rich_dragon_breath_bucket
---

# 木质温室

###### _letitgrowleitgrow_

这台机器当前已禁用。请改用工业温室！
