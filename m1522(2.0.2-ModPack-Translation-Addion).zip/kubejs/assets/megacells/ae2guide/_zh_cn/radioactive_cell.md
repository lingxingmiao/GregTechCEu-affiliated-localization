---
navigation:
  title: 放射性化学单元（AppMek专属）
  icon: radioactive_chemical_cell
  parent: index.md
  position: 050
categories:
  - megacells
item_ids:
  - radioactive_cell_component
  - radioactive_chemical_cell
---

# MEGA Cells：放射性化学单元

在 StaTech Industry 中此功能已被禁用。
