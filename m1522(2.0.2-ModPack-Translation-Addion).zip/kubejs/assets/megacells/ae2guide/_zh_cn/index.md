---
navigation:
  title: "附加模组：MEGA存储单元"
  position: 80
item_ids:
  - accumulation_processor
  - accumulation_processor_press
  - printed_accumulation_processor
  - sky_steel_ingot
  - sky_steel_block
---

# MEGA存储单元

![MEGA Cells标志](assets/logo.png)

## 介绍

**MEGA Cells**是应用能源2的附加模组，提供更高阶的存储，容量范围从**1M**
到高达**256M**，同时提供某些定制功能，例如更专业的存储单元和额外
相关工具。

## 入门指南

<Row>
  <ItemImage id="sky_steel_ingot" scale="4" />
  <ItemImage id="accumulation_processor" scale="4" />
</Row>

要在存储方面达到新高度，需要新材料。你需要采集的最重要资源是
搭建MEGA基础设施的准备非常充足， <ItemLink id="ae2:sky_stone_block" />因为这需要
与铁一起转化为**天钢**合金锭，以及
<ItemLink id="ae2:charged_certus_quartz_crystal" />。然而，仅靠水不足以进行金属加工，因此你需要一种
更高温的流体来熔化它们并将其转化。

<Row>
  <Recipe id="transform/sky_steel_ingot" />
</Row>

一旦你获得了一些天钢，你就可以用它来组装一种全新的处理器类型，称为**积累
处理器**。这种处理器几乎充当了所有MEGA设备的独特“骨干”，无论是标准
更大容量的单元还是任何其他专用工具。

压制机可以在打包机中制作。

从此刻起，你已准备好进一步体验“*MEGA Corp.*”提供的服务，并解锁全部潜力
你的ME存储与基础设施。

## 延伸阅读

<SubPages />
