---
navigation:
    title: '批量压缩机'
    icon: 'mi_tweaks:bulk_compactor'
    position: 5
    parent: stcm:batching_machines.md
item_ids:
    - mi_tweaks:bulk_compactor
---

# 批量压缩机

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="mi_tweaks:bulk_compactor" />
</GameScene>

批量压缩机是压缩机的批量处理版本。它可以以10%的EU折扣处理8个批次的物品！

<Recipe id="statech:mi_tweaks/bulk_compactor" />
