---
navigation:
    title: '批量机器'
    icon: 'mi_tweaks:large_chemical_reactor'
    position: 3
---

# 批量机器
