---
navigation:
    title: '诅咒食物'
    icon: 'kubejs:greg_cola'
    position: 1
    parent: stcm:items.md
item_ids:
    - kubejs:concrete_bar
    - kubejs:statech_energy
    - kubejs:sulfuric_acid_bottle
    - kubejs:concrete_and_clay_steak
    - kubejs:uranium_cereal
    - kubejs:fruity_pebbles
    - kubejs:concrete_pizza_slice
    - kubejs:bepsi
    - kubejs:coke_cola
    - kubejs:missing_texture_cookie
    - kubejs:abs_building_brick
    - kubejs:greg_cola
    - kubejs:nuka_cola
    - kubejs:pizza_slice
    - kubejs:concrete_pizza_slice
    - kubejs:pizza
    - kubejs:concrete_pizza
    - kubejs:pizza_dough
    - kubejs:uncooked_pizza
    - kubejs:fries
    - kubejs:gravy_bucket
    - kubejs:poutine_basket
    - modern_industrialization:mixed_ingot_iridium
    - yet_another_industrialization:cachaca
    - yet_another_industrialization:ai_slop
    - yet_another_industrialization:ultradense_metal_ball_burger
---

# 食物

<Row>
  <ItemImage id="kubejs:abs_building_brick" />
  <ItemImage id="yet_another_industrialization:ai_slop" />
  <ItemImage id="kubejs:bepsi" />
  <ItemImage id="yet_another_industrialization:cachaca" />
  <ItemImage id="kubejs:coke_cola" />
  <ItemImage id="kubejs:concrete_bar" />
  <ItemImage id="kubejs:concrete_and_clay_steak" />
  <ItemImage id="kubejs:fruity_pebbles" />
  <ItemImage id="kubejs:greg_cola" />
  <ItemImage id="kubejs:missing_texture_cookie" />
  <ItemImage id="modern_industrialization:mixed_ingot_iridium" />
</Row>
<Row>
  <ItemImage id="kubejs:nuka_cola" />
  <ItemImage id="kubejs:pizza_dough" />
  <ItemImage id="kubejs:uncooked_pizza" />
  <ItemImage id="kubejs:pizza" />
  <ItemImage id="kubejs:pizza_slice" />
  <ItemImage id="kubejs:concrete_pizza" />
  <ItemImage id="kubejs:concrete_pizza_slice" />
  <ItemImage id="kubejs:statech_energy" />
  <ItemImage id="kubejs:sulfuric_acid_bottle" />
  <ItemImage id="yet_another_industrialization:ultradense_metal_ball_burger" />
  <ItemImage id="kubejs:uranium_cereal" />
</Row>
<Row>
  <ItemImage id="kubejs:fries" />
  <ItemImage id="kubejs:gravy_bucket" />
  <ItemImage id="kubejs:poutine_basket" />
</Row>

这些食物对你的健康大有裨益！（请勿在现实生活中尝试）
