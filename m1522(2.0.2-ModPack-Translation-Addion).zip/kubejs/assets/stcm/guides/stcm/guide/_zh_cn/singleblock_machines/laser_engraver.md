---
navigation:
    title: '激光雕刻机'
    icon: 'modern_industrialization:laser_engraver'
    position: 0
    parent: stcm:singleblock_machines.md
item_ids:
    - modern_industrialization:laser_engraver
---

# 激光雕刻机

<GameScene zoom="4" interactive={true} fullWidth={true}>
    <Block id="modern_industrialization:laser_engraver" />
</GameScene>

激光雕刻机是一种单方块电动机器，允许你制作AE2印刷电路板以及Mob/Boss粉碎器模型。可以将其视为格雷科技化的压印器！

<Recipe id="kubejs:laser_engraver" />
