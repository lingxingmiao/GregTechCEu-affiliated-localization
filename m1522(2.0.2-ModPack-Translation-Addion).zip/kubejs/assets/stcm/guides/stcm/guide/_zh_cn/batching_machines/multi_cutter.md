---
navigation:
    title: '多重切割机'
    icon: 'mi_tweaks:multi_cutter'
    position: 0
    parent: stcm:batching_machines.md
item_ids:
    - mi_tweaks:multi_cutter
---

# 多重切割机

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="mi_tweaks:multi_cutter" />
</GameScene>

多重切割机是切割机的批量处理版本。它可以在享受40% EU折扣的情况下一次处理8个批次！

<Recipe id="statech:mi_tweaks/multi_cutter" />
