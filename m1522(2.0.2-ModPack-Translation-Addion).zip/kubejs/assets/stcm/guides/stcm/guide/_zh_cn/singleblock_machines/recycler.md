---
navigation:
    title: '回收'
    icon: 'modern_industrialization:recycler'
    position: 3
    parent: stcm:singleblock_machines.md
item_ids:
    - modern_industrialization:recycler
---

# 回收

<GameScene zoom="4" interactive={true} fullWidth={true}>
    <Block id="modern_industrialization:recycler" />
</GameScene>

回收机是一台单方块电动机器，允许你将大量物品转化为废料，废料可转化为UU物质（物品）。UU物质（仍为物品）可在物质制造器中用于生成多种材料。

输入物品越有价值，回收机产生废料的几率就越高。

回收器也可用于将神器转化为特殊的神器粉尘（你只能回收那些无法合成的，不错的尝试），这些粉尘可以在物质制造器中转化为拟态刷怪蛋。

<Recipe id="statech:modern_industrialization/recycler" />
