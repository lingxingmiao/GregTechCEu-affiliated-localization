---
navigation:
    title: '怪物粉碎器'
    icon: 'modern_industrialization:mob_crusher'
    position: 0
    parent: stcm:multiblock_machines.md
item_ids:
    - modern_industrialization:mob_crusher
---

# 怪物粉碎器

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="modern_industrialization:mob_crusher" />
</GameScene>

怪物粉碎器是一台机器，允许轻松获取怪物掉落物，而无需担心影响性能。

<Recipe id="statech:modern_industrialization/mob_crusher" />
