---
navigation:
    title: '量子太空探针发射器'
    icon: 'modern_industrialization:quantum_space_probe_launcher'
    position: 6
    parent: stcm:multiblock_machines.md
item_ids:
    - modern_industrialization:quantum_space_probe_launcher
---

# 量子太空探针发射器

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="modern_industrialization:quantum_space_probe_launcher" />
</GameScene>

量子太空探针发射器是一台多方块机器，允许你深入太空，使用太空探针收集各种太空材料。

<Recipe id="statech:modern_industrialization/quantum_space_probe_launcher" />
