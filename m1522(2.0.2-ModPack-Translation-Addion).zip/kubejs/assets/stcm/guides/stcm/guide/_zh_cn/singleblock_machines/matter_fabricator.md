---
navigation:
    title: '物质制造器'
    icon: 'modern_industrialization:matter_fabricator'
    position: 4
    parent: stcm:singleblock_machines.md
item_ids:
    - modern_industrialization:matter_fabricator
---

# 物质制造器

<GameScene zoom="4" interactive={true} fullWidth={true}>
    <Block id="modern_industrialization:matter_fabricator" />
</GameScene>

物质制造器是一种单方块电力机器，允许你将UU物质（物品）转化为若干实用资源！UU物质（仍指该物品）可通过在聚爆压缩机中处理废料制成。

有关废料的更多信息，请参见回收器页面。

<Recipe id="statech:modern_industrialization/matter_fabricator" />
