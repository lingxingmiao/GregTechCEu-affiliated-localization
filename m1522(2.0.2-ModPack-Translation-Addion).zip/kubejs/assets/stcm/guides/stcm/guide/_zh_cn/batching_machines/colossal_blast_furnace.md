---
navigation:
    title: '巨型高炉'
    icon: 'mi_tweaks:colossal_blast_furnace'
    position: 11
    parent: stcm:batching_machines.md
item_ids:
    - mi_tweaks:colossal_blast_furnace
---

# 巨型高炉

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="mi_tweaks:colossal_blast_furnace" />
</GameScene>

巨型高炉是高炉的批量处理版本。它能以 20% 的 EU 折扣进行 12 个批次的处理！

<Recipe id="statech:mi_tweaks/colossal_blast_furnace" />
