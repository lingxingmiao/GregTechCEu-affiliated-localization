---
navigation:
    title: 'StaTech Industry 2'
    icon: 'kubejs:statech_logo'
---

# StaTech Industry

欢迎来到 **StaTech Industry 2**！

该整合包的全新主要版本包含许多新机器以及机器的批量处理多方块变体。本指南将包含与 StaTech Industry 的具体新增内容、功能和配置相关的大部分信息，并将取代之前用于展示多方块结构的 Ponder。
