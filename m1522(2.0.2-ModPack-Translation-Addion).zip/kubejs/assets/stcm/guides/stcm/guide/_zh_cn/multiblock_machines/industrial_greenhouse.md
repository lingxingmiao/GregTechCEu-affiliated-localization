---
navigation:
    title: '工业温室'
    icon: 'modern_industrialization:greenhouse'
    position: 4
    parent: stcm:multiblock_machines.md
item_ids:
    - modern_industrialization:greenhouse
---

# 工业温室

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="modern_industrialization:greenhouse" />
</GameScene>

工业温室是一种多方块机器，允许你使用各种流体种植各种性质的树木，以获得更少或更多的高效产量。

<Recipe id="statech:modern_industrialization/greenhouse" />
