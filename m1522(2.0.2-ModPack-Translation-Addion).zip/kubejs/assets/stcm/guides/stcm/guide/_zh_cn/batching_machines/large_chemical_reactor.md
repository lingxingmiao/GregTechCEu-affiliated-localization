---
navigation:
    title: '大型化学反应器'
    icon: 'mi_tweaks:large_chemical_reactor'
    position: 1
    parent: stcm:batching_machines.md
item_ids:
    - mi_tweaks:large_chemical_reactor
---

# 大型化学反应器

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="mi_tweaks:large_chemical_reactor" />
</GameScene>

大型化学反应器是化学反应器的批量版本。它可以以50%的EU折扣处理4个批次的物品！

<Recipe id="statech:mi_tweaks/large_chemical_reactor" />
