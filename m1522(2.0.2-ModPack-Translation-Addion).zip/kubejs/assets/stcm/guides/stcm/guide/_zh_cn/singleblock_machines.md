---
navigation:
    title: '单方块机器'
    icon: 'modern_industrialization:laser_engraver'
    position: 1
---

# 单方块机器
