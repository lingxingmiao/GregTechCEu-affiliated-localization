---
navigation:
    title: '高容量拆包机'
    icon: 'mi_tweaks:high_capacity_unpacker'
    position: 4
    parent: stcm:batching_machines.md
item_ids:
    - mi_tweaks:high_capacity_unpacker
---

# 高容量拆包机

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="mi_tweaks:high_capacity_unpacker" />
</GameScene>

高容量拆包机是拆包机的批量版本。它可以以25%的EU折扣批量处理8个物品！

<Recipe id="statech:mi_tweaks/high_capacity_unpacker" />
