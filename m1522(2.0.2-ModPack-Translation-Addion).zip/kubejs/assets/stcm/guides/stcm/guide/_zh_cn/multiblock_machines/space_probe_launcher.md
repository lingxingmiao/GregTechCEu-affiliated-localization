---
navigation:
    title: '太空探针发射器'
    icon: 'modern_industrialization:space_probe_launcher'
    position: 5
    parent: stcm:multiblock_machines.md
item_ids:
    - modern_industrialization:space_probe_launcher
---

# 太空探针发射器

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="modern_industrialization:space_probe_launcher" />
</GameScene>

『空间』探针发射器是一种多方块机器，允许你使用基础、高级或超高级『空间』探针深入『空间』以收集各种『空间』材料。它需要在控制器下方放置探针计算机或相应等级的方块。

<Recipe id="statech:modern_industrialization/space_probe_launcher" />
