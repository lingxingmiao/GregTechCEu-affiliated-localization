---
navigation:
    title: '爆裂合金冶炼炉'
    icon: 'mi_tweaks:blast_alloy_smelter'
    position: 8
    parent: stcm:batching_machines.md
item_ids:
    - mi_tweaks:blast_alloy_smelter
---

# 爆裂合金冶炼炉

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="mi_tweaks:blast_alloy_smelter" />
</GameScene>

爆裂合金冶炼炉是合金冶炼炉的批量处理版本。它能以25%的EU折扣处理16个批次的物品！

<Recipe id="statech:mi_tweaks/blast_alloy_smelter" />
