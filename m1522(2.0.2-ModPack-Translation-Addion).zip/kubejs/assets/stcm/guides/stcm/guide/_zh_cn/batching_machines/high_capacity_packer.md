---
navigation:
    title: '高容量封装机'
    icon: 'mi_tweaks:high_capacity_packer'
    position: 3
    parent: stcm:batching_machines.md
item_ids:
    - mi_tweaks:high_capacity_packer
---

# 高容量封装机

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="mi_tweaks:high_capacity_packer" />
</GameScene>

高容量封装机是装机器的批量版本。它可以以25%的EU折扣批量处理8个物品！

<Recipe id="statech:mi_tweaks/high_capacity_packer" />
