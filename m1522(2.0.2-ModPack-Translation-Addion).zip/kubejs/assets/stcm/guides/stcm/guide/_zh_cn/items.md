---
navigation:
    title: '物品'
    icon: 'kubejs:greg_cola'
    position: 4
---

# 物品
