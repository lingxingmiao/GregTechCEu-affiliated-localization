---
navigation:
    title: '火箭部件组装器'
    icon: 'modern_industrialization:rocket_part_assembler'
    position: 2
    parent: stcm:singleblock_machines.md
item_ids:
    - modern_industrialization:rocket_part_assembler
---

# 火箭部件组装器

<GameScene zoom="4" interactive={true} fullWidth={true}>
    <Block id="modern_industrialization:rocket_part_assembler" />
</GameScene>

火箭部件组装器是一种单方块电力机器，允许你合成太空探针所需的部件！

<Recipe id="statech:modern_industrialization/rocket_part_assembler" />
