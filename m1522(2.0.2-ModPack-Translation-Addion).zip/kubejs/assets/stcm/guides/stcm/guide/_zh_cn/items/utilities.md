---
navigation:
    title: '实用工具'
    icon: 'kubejs:angel_ring'
    position: 3
    parent: stcm:items.md
item_ids:
    - kubejs:angel_ring
    - kubejs:fireproof_ring
    - artifacts:eternal_steak
    - artifacts:everlasting_beef
---

# 实用工具

<ItemImage id="kubejs:angel_ring" />

天使戒指在佩戴时可让您获得无限的自由创造飞行能力。如果您完成了光谱（Spectrum），最早在获得化学反应器（以进入末地）时即可制作它。您也可以在后期通过纯粹的技术进步获得它。

<ItemImage id="kubejs:fireproof_ring" />

防火戒指（目前）是一种仅可通过魔法途径获得的无限火焰抗性来源，佩戴后可让您无需担心熔岩或火焰伤害。
