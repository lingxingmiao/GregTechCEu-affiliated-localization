---
navigation:
    title: '太空探针'
    icon: 'kubejs:space_probe'
    position: 2
    parent: stcm:items.md
item_ids:
    - kubejs:basic_space_probe
    - kubejs:advanced_space_probe
    - kubejs:highly_advanced_space_probe
    - kubejs:space_probe
---

# 太空探针

<ItemImage id="kubejs:basic_space_probe" />
<ItemImage id="kubejs:advanced_space_probe" />
<ItemImage id="kubejs:highly_advanced_space_probe" />
<ItemImage id="kubejs:space_probe" />

各种太空探针是可以使用太空探针发射器发射到太空中的采矿设备。它们可以获取大量高级材料，使您能够执行各种操作，例如创建多方块结构、获取用于核反应堆的高级材料等。
