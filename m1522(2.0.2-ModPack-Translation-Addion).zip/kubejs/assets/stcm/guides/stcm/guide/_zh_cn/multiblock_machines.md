---
navigation:
    title: '多方块机器'
    icon: 'modern_industrialization:core_drill'
    position: 2
---

# 多方块机器
