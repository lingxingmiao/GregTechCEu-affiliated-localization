---
navigation:
    title: '超大电解室'
    icon: 'mi_tweaks:oversized_electrolysis_chamber'
    position: 9
    parent: stcm:batching_machines.md
item_ids:
    - mi_tweaks:oversized_electrolysis_chamber
---

# 超大电解室

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="mi_tweaks:oversized_electrolysis_chamber" />
</GameScene>

超大电解室是电解器的批量版本。它可以进行16个批次的处理，并享受20%的EU折扣！

<Recipe id="statech:mi_tweaks/oversized_electrolysis_chamber" />
