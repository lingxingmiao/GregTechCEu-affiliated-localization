---
navigation:
    title: '大型装配机'
    icon: 'mi_tweaks:large_scale_assembler'
    position: 12
    parent: stcm:batching_machines.md
item_ids:
    - mi_tweaks:large_scale_assembler
---

# 大型装配机

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="mi_tweaks:large_scale_assembler" />
</GameScene>

大型装配机是装配机的批量版本。它可以以15%的EU折扣进行16个批次的处理！

<Recipe id="statech:mi_tweaks/large_scale_assembler" />
