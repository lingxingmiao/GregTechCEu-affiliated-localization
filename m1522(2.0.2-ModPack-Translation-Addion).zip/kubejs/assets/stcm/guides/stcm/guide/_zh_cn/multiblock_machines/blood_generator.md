---
navigation:
    title: '血发生器'
    icon: 'modern_industrialization:blood_generator'
    position: 2
    parent: stcm:multiblock_machines.md
item_ids:
    - modern_industrialization:blood_generator
---

# 血发生器

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="modern_industrialization:blood_generator" />
</GameScene>

**血发生器**多方块结构最高输出 **8192 EU/t**，即 **HV 电压等级**的 **最大线缆传输速度**。在多方块结构内，血液消耗速率为 **1024 EU/mB**。**富含营养的龙息**也可使用，消耗速率为 **8192 EU/mB**。

<Recipe id="statech:modern_industrialization/blood_generator" />
