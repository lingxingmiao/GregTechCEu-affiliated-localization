---
navigation:
    title: '回收工厂'
    icon: 'mi_tweaks:recycling_factory'
    position: 15
    parent: stcm:batching_machines.md
item_ids:
    - mi_tweaks:recycling_factory
---

# 回收工厂

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="mi_tweaks:recycling_factory" />
</GameScene>

回收工厂是回收器的批量版本。它可以进行16个批次的处理，但没有EU折扣。抱歉，但事已至此⋯⋯

<Recipe id="statech:mi_tweaks/recycling_factory" />
