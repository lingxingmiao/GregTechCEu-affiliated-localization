---
navigation:
    title: '工业混合机'
    icon: 'mi_tweaks:industrial_mixing_machine'
    position: 7
    parent: stcm:batching_machines.md
item_ids:
    - mi_tweaks:industrial_mixing_machine
---

# 工业混合机

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="mi_tweaks:industrial_mixing_machine" />
</GameScene>

工业混合机是混合搅拌机的批量版本。它可以以20%的EU折扣处理12个批次的物品！

<Recipe id="statech:mi_tweaks/industrial_mixing_machine" />
