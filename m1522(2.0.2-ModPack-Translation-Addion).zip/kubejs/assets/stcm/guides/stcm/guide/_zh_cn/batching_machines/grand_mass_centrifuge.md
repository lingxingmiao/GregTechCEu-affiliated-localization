---
navigation:
    title: '大型质量离心机'
    icon: 'mi_tweaks:grand_mass_centrifuge'
    position: 10
    parent: stcm:batching_machines.md
item_ids:
    - mi_tweaks:grand_mass_centrifuge
---

# 大型质量离心机

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="mi_tweaks:grand_mass_centrifuge" />
</GameScene>

大型质量离心机是离心机的批量处理版本。它能以8个批次进行工作，并享受25%的EU折扣！

<Recipe id="statech:mi_tweaks/grand_mass_centrifuge" />
