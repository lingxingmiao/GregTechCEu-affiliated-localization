---
navigation:
    title: '极限真空冷冻器'
    icon: 'mi_tweaks:extreme_vacuum_cryofreezer'
    position: 13
    parent: stcm:batching_machines.md
item_ids:
    - mi_tweaks:extreme_vacuum_cryofreezer
---

# 极限真空冷冻器

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="mi_tweaks:extreme_vacuum_cryofreezer" />
</GameScene>

极限真空冷冻器是真空冷冻器的批量处理版本。它能以 30% 的 EU 折扣进行 12 个批次的处理！

<Recipe id="statech:mi_tweaks/extreme_vacuum_cryofreezer" />
