---
navigation:
    title: '奇点熔炉'
    icon: 'modern_industrialization:singularity_forge'
    position: 10
    parent: stcm:multiblock_machines.md
item_ids:
    - modern_industrialization:singularity_forge
---

# 奇点熔炉

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="modern_industrialization:singularity_forge" />
</GameScene>

奇点熔炉是一种多方块机器，允许你创建奇点。

<Recipe id="statech:modern_industrialization/singularity_forge" />
