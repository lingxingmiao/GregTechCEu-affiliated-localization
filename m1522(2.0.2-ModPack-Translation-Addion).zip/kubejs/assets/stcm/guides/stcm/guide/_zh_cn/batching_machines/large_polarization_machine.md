---
navigation:
    title: '大型极化机'
    icon: 'mi_tweaks:large_polarization_machine'
    position: 2
    parent: stcm:batching_machines.md
item_ids:
    - mi_tweaks:large_polarization_machine
---

# 大型极化机

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="mi_tweaks:large_polarization_machine" />
</GameScene>

大型极化机是极化器的批量处理版本。它可以以15%的EU折扣进行8个批次的处理！

<Recipe id="statech:mi_tweaks/large_polarization_machine" />
