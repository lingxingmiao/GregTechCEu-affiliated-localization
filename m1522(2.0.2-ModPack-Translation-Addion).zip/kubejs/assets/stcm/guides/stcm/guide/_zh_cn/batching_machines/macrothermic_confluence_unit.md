---
navigation:
    title: '宏观热汇合单元'
    icon: 'mi_tweaks:macrothermic_confluence_unit'
    position: 14
    parent: stcm:batching_machines.md
item_ids:
    - mi_tweaks:macrothermic_confluence_unit
---

# 宏观热汇合单元

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="mi_tweaks:macrothermic_confluence_unit" />
</GameScene>

宏观热汇合单元是热交换器的批量版本。它可以以10%的EU折扣进行16个批次的处理！

<Recipe id="statech:mi_tweaks/macrothermic_confluence_unit" />
