---
navigation:
    title: '核心钻'
    icon: 'modern_industrialization:core_drill'
    position: 3
    parent: stcm:multiblock_machines.md
item_ids:
    - modern_industrialization:core_drill
---

# 核心钻

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="modern_industrialization:core_drill" />
</GameScene>

核心钻是一台机器，可以使用戴斯钻头从主世界最深处钻取核心碎片。

<Recipe id="statech:modern_industrialization/core_drill" />
