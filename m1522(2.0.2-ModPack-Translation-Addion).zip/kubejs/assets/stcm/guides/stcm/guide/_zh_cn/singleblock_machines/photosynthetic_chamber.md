---
navigation:
    title: '光合室'
    icon: 'modern_industrialization:photosynthetic_chamber'
    position: 1
    parent: stcm:singleblock_machines.md
item_ids:
    - modern_industrialization:photosynthetic_chamber
---

# 光合室

<GameScene zoom="4" interactive={true} fullWidth={true}>
    <Block id="modern_industrialization:photosynthetic_chamber" />
</GameScene>

光合室是一台单方块电动机器，允许你以无卡顿的方式种植作物和花卉！

<Recipe id="statech:modern_industrialization/photosynthetic_chamber" />
