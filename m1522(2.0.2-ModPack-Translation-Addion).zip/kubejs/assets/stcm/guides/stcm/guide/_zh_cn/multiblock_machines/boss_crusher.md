---
navigation:
    title: 'Boss粉碎器'
    icon: 'modern_industrialization:boss_crusher'
    position: 1
    parent: stcm:multiblock_machines.md
item_ids:
    - modern_industrialization:boss_crusher
---

# Boss粉碎器

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="modern_industrialization:boss_crusher" />
</GameScene>

Boss粉碎器是一台机器，可以轻松刷取Boss型怪物的掉落物，这些掉落物可用于合成某些材料。

<Recipe id="statech:modern_industrialization/boss_crusher" />
