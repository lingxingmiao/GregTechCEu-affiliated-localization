---
navigation:
    title: '阵列拉丝机'
    icon: 'mi_tweaks:arrayed_wiremill'
    position: 6
    parent: stcm:batching_machines.md
item_ids:
    - mi_tweaks:arrayed_wiremill
---

# 阵列拉丝机

<GameScene zoom="1" interactive={true} fullWidth={true}>
    <MultiblockShape controller="mi_tweaks:arrayed_wiremill" />
</GameScene>

阵列式拉丝机是拉丝机的批量处理版本。它能以10%的EU折扣处理8个批次的物品！

<Recipe id="statech:mi_tweaks/arrayed_wiremill" />
